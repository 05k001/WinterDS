So with the first insertions we add 15 and 14 with normal rules. Then when we add 13 we will do a
single right rotation dropping 15 and promoting 14 to root (Fig1). 12 gets dropped in to left of 13
then 11 will require a single rotation to promote 12 up and create a new layer (Fig2). When we insert
10 to the left of 11 the tree becomes unbalenced. A single rotation on the root will solve this
(Fig3). Inserting 9 will require a single rotation to promote 10. (Fig4). Inserting 8 is rather
uneventful but 7 will require another rotation. (Fig5) Inserting 6 into the tree will require 10 and 8 to swap and rotate. (Fig6) Adding 5 will rotate the node and promote 6.Addind 4 and 3 will all
require rotations of the tree. (Fig7) Adding 2 and 1 will require 2 more rotations till we get to our
final tree (Fig8).
