With bottom up splay tree we will rotate as we insert the elements. Im being kind of lazy so maybe Ill just make the end result graph and work backwards. We rotate on almost every insertion but things
even out eventually. So my graph drawing program makes single child nodes wierd. Im going to need to check out the documentation.




